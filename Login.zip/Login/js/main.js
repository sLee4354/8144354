﻿// Your code here!

function loginSubmit() {
    var id = document.getElementById("username").value;
    var pw = document.getElementById("password").value;
    if (id == "1" && pw == "1") {
        alert(id + ", you are login now!");
        window.location = "dashboard.html";
        
    } else if (id == "1" && pw != "1") {
        alert("wrong password. Try again!");
    } else {
        alert("No exist username. Please join us!");
    }
    return false;
}
